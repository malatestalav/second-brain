# Cliente: per chi lavoro

Questo file dice all'intelligenza artificiale a chi stai parlando. È il file più importante dei tre: se lei sa chi legge, scrive le parole giuste anche quando tu non gliele dici.

Pensa a una persona vera, una cliente che hai seguito e che ti è rimasta in mente. Rispondi come se descrivessi lei a un'amica. Sostituisci le parti tra parentesi quadre. Sotto ogni sezione c'è un esempio inventato (le clienti di una nutrizionista che non esiste): leggilo, poi **cancellalo**.

---

## La persona

La mia cliente tipo è [donna / uomo / tutti e due], ha [età, anche una fascia], vive [dove, se conta] e fa [lavoro].
La sua giornata è [com'è fatta: orari, figli, stress, tempo libero].
Ha già provato [cosa ha già tentato per risolvere il problema, prima di arrivare da te].
Mi trova [dove ti trova: Instagram, passaparola, Google, un'amica].

> **Esempio (cancellami):**
> La mia cliente tipo è una donna, tra i 35 e i 50 anni, lavora in ufficio o ha una sua attività.
> La sua giornata è piena: sveglia presto, lavoro, figli, cena alle nove di sera fatta di corsa. Il tempo per sé lo trova dopo le dieci, sul divano, con il telefono in mano.
> Ha già provato almeno tre diete, un'app che conta le calorie, e un periodo di digiuno intermittente. Ogni volta ha perso qualche chilo e li ha ripresi tutti.
> Mi trova su Instagram, di solito da un reel in cui racconto una cosa che le è successa identica.

## Il problema che ha quando arriva da me

Quando mi scrive la prima volta mi dice, con le sue parole: "[la frase tipica del primo messaggio]".
Il problema che vede lei è [come lo descrive lei].
Il problema vero, secondo me, è [come lo vedi tu, che spesso è diverso].
La cosa che la fa più arrabbiare o vergognare è [cosa].

> **Esempio (cancellami):**
> Quando mi scrive la prima volta mi dice: "non ce la faccio più, so tutto sul cibo ma poi la sera crollo".
> Il problema che vede lei è che non ha forza di volontà.
> Il problema vero, secondo me, è che salta i pasti di giorno e arriva a sera con una fame che non si controlla con la volontà.
> La cosa che la fa più vergognare è mangiare di nascosto dopo che i figli sono andati a letto.

## Cosa vuole davvero

Se le chiedo cosa vuole, mi dice: "[la risposta di superficie]".
Ma quello che vuole davvero è [il desiderio sotto: come vuole sentirsi, cosa vuole poter fare].
Il giorno in cui avrà risolto, la scena che immagina è [descrivila: dove è, cosa fa, con chi].

> **Esempio (cancellami):**
> Se le chiedo cosa vuole, mi dice: "perdere 8 chili".
> Ma quello che vuole davvero è smettere di pensare al cibo tutto il giorno. Sedersi a cena con la famiglia e mangiare quello che c'è senza fare i conti.
> La scena che immagina è: estate, in spiaggia, in costume, che gioca con i figli senza tenere il pareo addosso.

## Cosa la frena

Prima di comprare pensa: "[obiezione 1, con le sue parole]".
E anche: "[obiezione 2]".
E anche: "[obiezione 3]".
Quello che le rispondo di solito è: [la tua risposta a ciascuna, breve].
Ha paura che [la paura di fondo: che non funzioni, di sentirsi giudicata, di buttare soldi].

> **Esempio (cancellami):**
> Prima di comprare pensa: "l'ho già fatto mille volte, perché stavolta dovrebbe funzionare".
> E anche: "non ho tempo per cucinare cose elaborate".
> E anche: "mio marito e i miei figli mangiano normale, non posso fare due cene".
> Quello che le rispondo: che non è una dieta, quindi non c'è niente da "fare" in più. Che si mangia quello che c'è in casa. Che la cena è una sola per tutti.
> Ha paura di fallire un'altra volta e di doverlo raccontare a qualcuno.

## Come parla

Le parole che usa per descrivere il problema: [3-5 parole o espressioni sue, prese dai messaggi veri].
Le parole che NON usa mai (e che quindi non devo usare io): [parole tecniche o da esperto che lei non direbbe].
Il tono con cui mi scrive è [confidenziale / formale / disperato / ironico].
Mi dà del [tu / lei].

> **Esempio (cancellami):**
> Le parole che usa: "sgarro", "crollo", "mi sono lasciata andare", "ricomincio lunedì", "mi sono abbuffata".
> Le parole che non usa mai: "deficit calorico", "macronutrienti", "composizione corporea", "compliance".
> Il tono con cui mi scrive è confidenziale, spesso con un po' di vergogna. Tanti "scusa se ti disturbo".
> Mi dà del tu.

## Chi NON è il mio cliente

Non lavoro con [tipo di persona 1] perché [motivo].
Non lavoro con [tipo di persona 2] perché [motivo].
Se mi scrive una persona così, [cosa fai: la mandi da qualcun altro, le dici di no, le proponi altro].

> **Esempio (cancellami):**
> Non lavoro con chi vuole un piano alimentare da seguire alla lettera, perché è l'opposto di quello che faccio.
> Non lavoro con atleti o chi fa gare, perché lì servono numeri e io non lavoro coi numeri.
> Non lavoro con chi ha un disturbo alimentare diagnosticato, perché serve un'équipe e io non lo sono.
> Se mi scrive una persona così, le rispondo con gentilezza e le passo il contatto di una collega.
