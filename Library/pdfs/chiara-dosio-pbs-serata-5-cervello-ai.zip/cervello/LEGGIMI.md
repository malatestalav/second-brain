# Il tuo cervello AI

Questa cartella è il tuo cervello. Dentro ci sono tre cartelle, e in ognuna un file di testo che si chiama come la cartella.

- **Offerta** → `offerta.md` → chi sei, cosa fai, cosa vendi
- **Cliente** → `cliente.md` → per chi lavori
- **Voce** → `voce.md` → come scrivi, e cosa non fai mai

Quando l'intelligenza artificiale deve scrivere qualcosa per te (una mail, un post, una caption, una risposta a un messaggio) prima legge questi tre file. Per questo scrive come te, per la tua cliente, verso la tua offerta.

## Come si compila

1. Apri il file con il Blocco note (Windows) o con TextEdit (Mac). Va bene anche qualunque altro programma di testo. Non serve niente di speciale.
2. Ogni riga ha una parte tra parentesi quadre, così: `[scrivi qui]`. Cancella le parentesi e scrivi la tua risposta al posto loro.
3. Sotto ogni sezione trovi un **esempio** già compilato. È inventato: una nutrizionista che non esiste. Serve solo a farti capire che tipo di risposta ci va. **Quando hai scritto la tua, cancella l'esempio.** Se lo lasci, l'intelligenza artificiale crede che sia roba tua.
4. Scrivi come parli. Frasi normali, niente forma ufficiale, niente frasi da presentazione. Se una domanda non ti riguarda, cancella la riga.
5. Salva. Fatto.

## Tre cose da sapere

**Non deve essere perfetto.** Un file scritto male ma vero vale più di uno scritto bene ma generico. Puoi tornarci quando vuoi.

**Più ci metti, più ti somiglia.** Se ti viene in mente una cosa in più (una frase che dici sempre, un'obiezione che senti ogni settimana, un cliente che non vuoi più) aggiungila. Non c'è un limite.

**Le correzioni finiscono qui.** Quando l'intelligenza artificiale sbaglia qualcosa ("questa parola non la uso mai", "la mia cliente ha 40 anni, non 25") non correggerla e basta: digli **"aggiungilo al cervello"**. La correzione va nel file giusto, una volta sola, e da lì in poi non sbaglia più.

## La cartella skill

Dentro `skill` c'è `anti-slop.md`: la checklist che passo io su ogni testo prima di pubblicarlo, per togliere le impronte da intelligenza artificiale (le frasi da cancellare, i pattern vietati, il test finale). Quando ti scrive qualcosa, digli **"passalo con la skill anti-slop"** e lui lo rilegge con quella lista.

## Come si usa

Metti la cartella `cervello` sul desktop. Quando apri Claude Code dentro questa cartella, lui legge i tre file prima di scrivere qualsiasi cosa.

Se vuoi aggiungere altro (le domande frequenti, i testimonial, la storia di come hai iniziato) puoi creare una cartella nuova con dentro un file di testo. Stessa logica: nome semplice, scritto come parli.
