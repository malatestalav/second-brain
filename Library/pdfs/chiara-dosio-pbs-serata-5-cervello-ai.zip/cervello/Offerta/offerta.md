# Offerta: chi sono, cosa faccio, cosa vendo

Questo file dice all'intelligenza artificiale cosa vendi e perché una persona dovrebbe comprarlo da te. Senza questo file, quando le chiedi una mail o un post, lei scrive cose generiche che potrebbero valere per chiunque faccia il tuo mestiere.

Sostituisci ogni parte tra parentesi quadre con le tue parole. Sotto ogni sezione c'è un esempio inventato (una nutrizionista che non esiste): leggilo per capire, poi **cancellalo** e lascia solo le tue righe.

---

## Chi sono

Mi chiamo [nome e cognome] e sono [la tua professione].
Lavoro [online / in studio a città / tutte e due] da [quanti anni].
Prima di fare questo lavoro facevo [cosa facevi prima, se c'entra con la tua storia].
Ho iniziato perché [la cosa vera che ti ha spinto, in due righe].
La cosa che so fare meglio di tutti è [una frase sola].

> **Esempio (cancellami):**
> Mi chiamo Giulia Ferrante e sono una nutrizionista.
> Lavoro online da 6 anni, prima avevo uno studio a Verona.
> Prima facevo la biologa in un laboratorio di analisi. Vedevo passare referti di persone che facevano diete da 20 anni e stavano sempre uguali.
> Ho iniziato perché io stessa ho fatto tutte le diete del mondo e l'unica cosa che ha funzionato è stata smettere di contare.
> La cosa che so fare meglio di tutti è togliere alle persone l'ansia del cibo senza fargli pesare niente.

## Cosa vendo

Il mio servizio principale si chiama [nome del percorso o del servizio].
È [un percorso di X mesi / un pacchetto di N incontri / una consulenza singola / un corso online].
Funziona così: [come si svolge, in 3-4 righe, come lo spiegheresti a voce a una persona che non ti conosce].
Alla fine la persona [cosa ha in mano, cosa è cambiato].
Non è adatto a chi [chi non dovrebbe comprarlo].

> **Esempio (cancellami):**
> Il mio servizio principale si chiama "Mangiare in pace".
> È un percorso di 4 mesi, uno a uno.
> Funziona così: ci sentiamo una volta ogni due settimane in videochiamata. Non ti do una dieta, ti do tre regole alla volta e le proviamo insieme. Tra una chiamata e l'altra mi scrivi su WhatsApp quando hai un dubbio. Ogni mese guardiamo cosa è cambiato, non sulla bilancia ma su come ti senti a tavola.
> Alla fine la persona sa mangiare senza pensarci, ha smesso di fare "strappi" e non ha più bisogno di me.
> Non è adatto a chi vuole perdere 10 chili per il matrimonio tra un mese.

## Perché il mio metodo è diverso

La maggior parte dei [tuoi colleghi] fa [cosa fanno gli altri, senza sputare veleno].
Io invece [la tua differenza, concreta].
Lo chiamo [se hai un nome per il tuo metodo, mettilo qui; altrimenti cancella la riga].
Le tre cose su cui insisto sempre sono: [1], [2], [3].

> **Esempio (cancellami):**
> La maggior parte dei nutrizionisti dà un piano alimentare con le grammature e ci si vede dopo un mese.
> Io invece non do piani. Lavoro su come la persona si comporta con il cibo, e la dieta viene da sola.
> Lo chiamo "metodo delle tre regole".
> Le tre cose su cui insisto sempre sono: niente cibi vietati, niente bilancia in casa, si mangia seduti.

## Come si entra

Per lavorare con me la persona deve [prenotare una call / compilare un questionario / scrivermi in DM / comprare direttamente dal sito].
La call dura [minuti] e serve a [capire se posso aiutarla / spiegarle il percorso].
Posso seguire [quante persone alla volta], quindi [se ci sono tempi di attesa o posti limitati, veri].

> **Esempio (cancellami):**
> Per lavorare con me la persona deve compilare un questionario sul mio sito e poi prenotare una chiamata gratuita di 30 minuti.
> La chiamata serve a capire se il problema è davvero il cibo o è altro. Se è altro glielo dico e la mando da qualcun altro.
> Posso seguire 20 persone alla volta, quindi di solito si parte il mese dopo.

## Altri servizi

Oltre al servizio principale ho anche [altri servizi, uno per riga, con una riga di spiegazione ciascuno].
Se una persona non può permettersi il percorso completo le propongo [cosa].
Ai clienti che hanno finito propongo [cosa, se esiste].

> **Esempio (cancellami):**
> Oltre al percorso ho anche una consulenza singola di un'ora, per chi ha una domanda precisa e basta.
> Ho anche un piccolo corso registrato, "La spesa in 20 minuti", per chi non sa da dove partire.
> Ai clienti che hanno finito propongo un mantenimento: una chiamata al mese per sei mesi.

## Prove

Ho seguito [quante persone] finora.
I risultati che ottengono di solito sono [cosa succede davvero, senza gonfiare].
Le frasi che mi dicono più spesso alla fine: "[frase 1]", "[frase 2]".
Cose che posso dire di me: [titoli, formazione, pubblicazioni, interviste, se ci sono].

> **Esempio (cancellami):**
> Ho seguito circa 300 persone finora.
> I risultati di solito sono: dopo un mese smettono di pesarsi tutti i giorni, dopo tre non hanno più la fame nervosa la sera.
> Le frasi che mi dicono più spesso alla fine: "non pensavo si potesse mangiare così", "mi sono tolta un peso, e non parlo dei chili".
> Cose che posso dire di me: laurea in biologia, master in nutrizione, iscritta all'albo dal 2016.
