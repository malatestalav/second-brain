# Skill anti-slop

Questa è la checklist che passo su ogni testo prima di consegnarlo: mail, post, caption, risposte ai messaggi, schede per le clienti. Serve a togliere le impronte da intelligenza artificiale. Vale per italiano e inglese.

Come si usa: quando l'intelligenza artificiale ti scrive un testo, digli "passalo con la skill anti-slop". Lui lo rilegge con questa lista e ti restituisce la versione pulita.

Fonte: memo Leila Hormozi (Acquisition.com).

---

## 1. Frasi tossiche da CANCELLARE

Mai usare. Sostituire come indicato. Vale anche se il tono "suona giusto".

| Frase tossica | Dillo invece |
|---|---|
| Delve into / Unpack | Guarda / Scomponi / Vediamo |
| This signals that / This underscores | I clienti fanno X, quindi cambiamo Y |
| Navigate the complexities of | Specifica QUALE complessità — o taci |
| In an ever-changing / ever-evolving landscape | (cancella, non dice nulla) |
| Synergies / Leverage our learnings | Cosa ha funzionato, cosa no, cosa cambiamo |
| Holistic approach | Spiega l'approccio, non etichettarlo |
| Moreover / Furthermore / Additionally | (vai al punto. Se serve, "e" / "poi") |
| Importantly / It's worth noting / Notably | (se è importante si vede dal contenuto) |
| Lean into / Foster a culture of | (corporate therapy, cancella) |
| Ultimately, the goal is | (se vale per qualsiasi azienda, cancella) |
| Quietly underscores / Quietly signals | Se è importante, "Questo è importante perché..." |
| Inoltre / In aggiunta / Pertanto | "e", "poi", "quindi" — o niente |
| In un panorama in continua evoluzione | (cancella) |
| Approccio olistico / sinergie | (descrivi cosa fai, non l'etichetta) |
| È importante notare che / Vale la pena sottolineare | (cancella, mostra l'importanza nei fatti) |

## 1b. Riempitivi/intensificatori vuoti (IT) — CANCELLARE

Parole-fiducia e amplificatori che non aggiungono informazione. Il fatto deve reggersi da solo: se è vero si vede, l'aggettivo lo indebolisce. Toglile, non sostituirle con un sinonimo.

| Parola riempitiva | Cosa fare |
|---|---|
| davvero / veramente / realmente / sul serio | cancella ("funziona davvero" → "funziona") |
| concreto / concreta / concretamente | cancella, o mostra il fatto concreto invece di chiamarlo tale |
| utile / utili | cancella, o di' A COSA serve ("consigli utili" → "consigli su X") |
| magico / magica / magia | cancella ("strategia magica" → descrivi cosa fa) |
| onesto / onesta / onesti (come parola-fiducia) | cancella; la fiducia si mostra coi fatti ("chiacchierata onesta" → "chiacchierata, senza pitch") |
| reale / reali (come enfasi: "casi reali", "risultati reali") | cancella l'enfasi; "in tempo reale" idiomatico è ok |
| potente / efficace / straordinario / incredibile / pazzesco | cancella; mostra il numero o l'effetto |
| semplicemente / letteralmente / assolutamente | cancella |
| autentico / genuino / vero (come etichetta) | cancella; descrivi, non etichettare |

Regola: prima di consegnare, cerca queste parole e toglile. Se la frase perde senso togliendole, allora dicevano qualcosa — riscrivi col fatto specifico, non con l'aggettivo.

## 2. Pattern strutturali VIETATI

### a. Bold-colon-bullet
```
no   **Clarity:** Ensure your memo is clear and concise.
no   **Allineamento:** Tutti gli stakeholder sulla stessa pagina.
ok   Il memo deve essere chiaro. Punto.
```
Sembra una slide motivazionale. Usa frasi normali.

### b. Negazione forzata "non X, ma Y"
```
no   "Non si tratta di vendere prodotti, ma di costruire relazioni."
no   "It's not about X, it's about Y."
ok   "Costruiamo relazioni." (di' Y e basta)
```

### c. Ripetizioni a staccato "do this, not this"
```
no   "Non questo. Non quello. Non quell'altro. Ma questo."
no   "Do X. Don't Y. Do Z. Avoid W."
ok   Una frase che dice cosa fare. Senza la sequenza retorica.
```

### d. Avverbi gonfiabili
```
no   "quietly underscores", "deeply transformative", "fundamentally shifts"
no   "profondamente", "sostanzialmente", "radicalmente"
ok   Di' il fatto, lascia decidere alla lettrice se è profondo.
```

### e. Voce da corporate therapist
```
no   "This is a powerful opportunity to lean into our strengths and foster a culture of accountability."
no   "Una grande opportunità per valorizzare i punti di forza del team."
ok   "Giulia mi manda il diario alimentare entro venerdì."
```
Se nessuno parla così a un aperitivo, non lo scrivi.

### f. Fiocchetto finale
```
no   "Ultimately, the goal is to build a more resilient and agile organization."
no   "In definitiva, l'obiettivo è creare valore sostenibile."
ok   (cancella la conclusione. Se vale per qualsiasi azienda, non vale per noi.)
```

### g. "Suona smart ma non dice niente"
Test: leggi il paragrafo, prova a riassumerlo in UNA frase semplice. Se non riesci — cancella.

### h. Auto-riferimento AI ("I am" / "I'm" / "Io" throat-clearing)
```
no   "I'm pleased to help with this analysis."
no   "Io penso che sia importante notare che..."
no   "Personalmente ritengo che..."
ok   (vai dritto al contenuto. Niente intro su chi parla.)
```

### i. Em-dash decorativo a raffica
```
no   "Il prodotto — che è davvero unico — funziona — e lo abbiamo testato."
ok   Un em-dash per concetto. Mai due nello stesso paragrafo.
```

### j. Liste a 5+ bullet quando una frase basta
```
no   - Punto chiave 1
     - Punto chiave 2
     - Punto chiave 3
ok   "I tre fattori sono A, B e C."
```

### k. Staccato a tre frasi (ritmo da slogan)
```
no   "Funziona. Lo abbiamo testato. I numeri lo dimostrano."
no   "It works. We tested it. The numbers prove it."
no   Tre (o più) frasi corte di fila, una dietro l'altra, come fendenti.
ok   "Lo abbiamo testato e i numeri confermano che funziona."
```
Il punto fermo usato come effetto drammatico è un AI tell. Unisci le frasi con "e", "perché", "quindi", o usa una virgola. Mai sequenze di micro-frasi punto-punto-punto per dare enfasi.

### l. Preamboli da assistant
```
no   "Great question!", "Certo!", "Ottima domanda"
no   "Spero questo aiuti", "Fammi sapere se ti serve altro"
ok   (vai al contenuto. Niente saluti, niente chiusure di cortesia AI)
```

## 3. Come scrivere invece

1. **Parla prima, scrivi dopo.** Le parole che escono dalla bocca suonano umane.
2. **L'AI rifinisce IL TUO draft, non lo sostituisce.** Chiedi: "Cosa manca?" / "Dove sono poco chiaro?" / "Stringi senza cambiare la mia voce".
3. **Mai dare un topic e dire 'scrivi il memo'.** I bullet che mandi all'AI valgono più del memo che ne esce.

## 4. Test rapido prima di consegnare

- Ogni frase dice qualcosa di **specifico** sul contesto? Se no — taglia.
- Lo diresti **a voce** a una persona reale? Se no — riscrivi.
- La conclusione vale **solo per noi** o per qualsiasi azienda? Se per qualsiasi — cancella.
- "Moreover/Furthermore/Inoltre/In aggiunta"? — Sostituisci o elimina.
- "I'm/Io penso/Personalmente" come throat-clearing? — Cancella.
- Pattern "non X, ma Y" o "do X, not Y"? — Riscrivi in positivo.
- Tre frasi corte di fila punto-punto-punto per enfasi? — Uniscile con "e/perché/quindi".
- Bold-colon-bullet? — Riscrivi in frasi.
- Riempitivi vuoti ("davvero/concreto/utile/magico/onesto/reale" come enfasi)? — Cancellali (vedi 1b).

## 5. Quando NON si applica

- File di codice (.ts, .py, .json, ecc.).
- Output strutturati per macchine (CSV, SQL, log).
- Citazioni testuali da fonti esterne.
